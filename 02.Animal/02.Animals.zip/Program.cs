﻿using System;


class Program
{
    static void Main(string[] args)
    {
        Animals cat = new Cat("Pesho", "Whiskas");
        Animals dog = new Dog("Gosho", "Meet");

        Console.WriteLine(cat.ExplainSelf());
        Console.WriteLine(dog.ExplainSelf());
    }
}