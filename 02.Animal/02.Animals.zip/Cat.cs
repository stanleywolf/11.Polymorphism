﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cat : Animals
{
    public Cat(string name, string favouriteFood) : base(name, favouriteFood)
    {
    }

    public override string ExplainSelf()
    {
        var result = base.ExplainSelf() + Environment.NewLine + "MEEOW";
        return result;
    }
}